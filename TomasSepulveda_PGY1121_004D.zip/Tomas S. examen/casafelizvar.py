import os
import numpy as np
def llenar(aa,otro):
    p=1
    for i in range(10):
        for j in range(4):
            aa[i,j]=p
            otro[i,j]=p
            p=1
def valiaOp():
    pp=0
    while(True):
        try:
            pp=int(input(" Elige opcion: "))
            if(pp>=1 and pp<=5):
                break
            else:
                print(" Debe ingresar la opcion que desea entre 1 y 5 ")
        except ValueError:
            print(" Debe ser numero entero ")
    return pp 
def mostrarDisp(aa):
    os.system("cls")
    for i in range(10):
        print("\n")
        for j in range(4):
            if(j==1 or j==5):
                print("\t",aa[i,j],end="    ")
            else:
                print("\t",aa[i,j], end="  ")
        print("\n\n")            
def pisoep():
    os.system("cls")
    ss=0
    while(True):
        try:
            ss=int(input(" Ingresar el piso que desea entre el 1 al 10"))
            if(ss>=1 and ss<=10):
                break
            else:
                print("Error debe ser un piso entre el 1 y 10")
        except ValueError:
            print("Debe ser entero ")
    return ss
def compDep():
    os.system("cls")
    pis=""
    while(len(pis)<=0):
        print("A")
        print("B")
        print("C")                
        print("D")
        print()
        pis=input("Elige departamento :").lower()
        if(pis!="A" and pis!="B" and pis!="C" and pis!="D" ):
            print("Debe ingresar una opcion correcta")
            pis=""
    return pis
def disponible(dep,pis):
    for i in range(10):
        for j in range(4):
            if(pis==dep[i,j]):
                return True
    return False
def compraPiso(aa,dep,dd,otro,run):
    if(dd=="A"):
        pago=3800
    if(dd=="B"):
        pago=3000
    if(dd=="C"):
        pago=2800
    if(dd=="D"):
        pago=3500
    for i in range(10):
        for j in range(4):
            if(dep==aa[i,j]):
                while(True):
                    while(True):
                        try:
                            runt=int(print(" el Rut debe tener 8 digitos minimo "))
                            if(runt<99999999):
                                print("Error , debe tener al menos 8 digitos ")
                            else:
                                break
                        except ValueError:
                            print("Debe ser entero")
                    if(len(run)>0):
                        sw=0
                        for y in range(len(run)):
                            if(runt==run[y]):
                                sw=1
                        if(sw==1):
                            print("El rut ya existe, verifique rut, no se puede agregar al comprador")
                        else:
                            run.append(runt)
                            break
                    else:
                        runt.append(runt)
                        break

def listado(r):
    r.sort()
    print("lista de compradores")
    print("\t",r)

def totalVenta(aa):
    suma=0
    for i in range(10):
        for j in range(4):
            if(aa[i,j]!=0 and aa [i,j]>3):
                suma+=aa[i,j]
    return suma 
