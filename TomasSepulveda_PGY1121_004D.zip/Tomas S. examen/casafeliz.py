
import os 
import numpy as np 
import casafelizvar as ca 
dep=np.empty([10,4],type(int))
otro=np.empty([10,4],type(int))
ca.llenar(dep,otro)
pis=0
run=[]
op=0
suma=0
while(op!=5):
    os.system("cls")
    print(" 1. Comprar departamento ")
    print(" 2. Mostrar departamentos disponibles ")
    print(" 3. Ver listado de compradores ")
    print(" 4. Mostrar ganancias totales ")
    print(" 5. Salir ")
    op=ca.valiaOp()
    if(op==1):
        dd=ca.pisoep()
        ca.mostrarDisp(dep)
        pis=ca.compDep()
        cc=ca.disponible(dep,pis)
        if (cc):
            print("Departamento aun Disponibles ")
            pagar=ca.compraPiso(dep,dd,run)
            print("\t El total es de :", pagar)
            os.system("pause")
    if(op==2):
        ca.mostrarDisp(dep)
        os.system("pause")
    if(op==3):
        ca.listado(run)
        os.system("pause")
    if(op==4):
        suma=0
        suma=ca.totalVenta(otro)
        if(suma==0):
            print("\t no se han vendido departamentos lamentablemente ")
        else:
            print("\t Este departamento no se ha podido vender")
        os.system("pause")        
    if(op==5):
        print("Muchas gracias por usar mi codigo, Adios :D")
        print("Tomas Sepulveda 11/07/2023")
        break

